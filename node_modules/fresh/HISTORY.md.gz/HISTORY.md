0.2.4 / 2014-09-07
==================

 * Support Node.js 0.6

0.2.3 / 2014-09-07
==================

 * Move repository to jshttp

0.2.2 / 2014-02-19
==================

 * Revert "Fix for blank page on Safari reload"

0.2.1 / 2014-01-29
==================

 * fix: support max-age=0 for end-to-end revalidation

0.2.0 / 2013-08-11
==================

  * fix: return false for no-cache
