/*!
 * ws: a node.js websocket client
 * Copyright(c) 2011 Einar Otto Stangvik <einaros@gmail.com>
 * MIT Licensed
 */
 
module.exports.Validation = {
  isValidUTF8: function(buffer) {
    return true;
  }
};

