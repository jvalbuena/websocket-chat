
# escape-html

  Escape HTML entities

## Example

```js
var escape = require('escape-html');
escape(str);
```

## License

  MIT